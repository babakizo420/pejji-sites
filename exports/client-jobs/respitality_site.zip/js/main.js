document.addEventListener('DOMContentLoaded', () => {
    // 1. Navigation scroll effect
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 20) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // 2. Fade up animations using Intersection Observer
    const fadeElements = document.querySelectorAll('.fade-up');
    
    // Check if user prefers reduced motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!prefersReducedMotion) {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.15
        };

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target); // Only animate once
                }
            });
        }, observerOptions);

        fadeElements.forEach(el => observer.observe(el));
    } else {
        // immediately show elements
        fadeElements.forEach(el => el.classList.add('visible'));
    }

    // 3. Simple Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            alert('Mobile Menu open');
        });
    }

    // 4. Contact Form Handling
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = contactForm.querySelector('button[type="submit"]');
            const originalText = btn.textContent;
            
            // Visual feedback
            btn.textContent = 'Sending...';
            btn.disabled = true;
            
            // Simulate network request
            setTimeout(() => {
                btn.textContent = 'Message Sent';
                btn.style.backgroundColor = 'var(--primary-color)';
                btn.style.color = 'var(--accent-color)';
                
                setTimeout(() => {
                    contactForm.reset();
                    btn.textContent = originalText;
                    btn.disabled = false;
                    btn.removeAttribute('style');
                }, 3000);
            }, 1000);
        });
    }
});
