window.onload = () => document.body.classList.add('loaded');

// Scroll Observer for Animations and Nav
const nav = document.querySelector('.nav');
window.addEventListener('scroll', () => {
    if(window.scrollY > 40) {
        nav.classList.add('scrolled');
    } else {
        nav.classList.remove('scrolled');
    }
});

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if(entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// Interactive Shopping Cart State Logic
let cart = [];
const cartToggle = document.getElementById('cart-toggle');
const closeCart = document.getElementById('close-cart');
const cartOverlay = document.getElementById('cart-overlay');
const cartSidebar = document.getElementById('cart-sidebar');
const cartItemsContainer = document.getElementById('cart-items');
const cartCountEls = document.querySelectorAll('.cart-count');
const cartCountTitle = document.querySelector('.cart-count-title');
const cartSubtotalEl = document.getElementById('cart-subtotal');
const checkoutBtn = document.getElementById('checkout-btn');

function formatMoney(amount) {
    return '₦' + parseInt(amount).toLocaleString();
}

function updateCartUI() {
    // Update counts
    cartCountEls.forEach(el => el.textContent = cart.length);
    cartCountTitle.textContent = `(${cart.length})`;

    // Render items
    if(cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-msg">Your bag is currently empty.</p>';
        checkoutBtn.disabled = true;
        cartSubtotalEl.textContent = '₦0';
    } else {
        checkoutBtn.disabled = false;
        let html = '';
        let total = 0;
        
        cart.forEach((item, index) => {
            total += parseInt(item.price);
            html += `
                <div class="cart-item">
                    <img src="${item.img}" class="c-item-img" alt="${item.name}">
                    <div class="c-item-info">
                        <h4 class="c-item-title">${item.name}</h4>
                        <p class="c-item-price">${formatMoney(item.price)}</p>
                        <button class="remove-item" onclick="removeFromCart(${index})">Remove</button>
                    </div>
                </div>
            `;
        });
        
        cartItemsContainer.innerHTML = html;
        cartSubtotalEl.textContent = formatMoney(total);
    }
}

window.removeFromCart = function(index) {
    cart.splice(index, 1);
    updateCartUI();
};

function openCart() {
    cartOverlay.classList.add('active');
    cartSidebar.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCartFunc() {
    cartOverlay.classList.remove('active');
    cartSidebar.classList.remove('active');
    document.body.style.overflow = 'auto';
}

cartToggle.addEventListener('click', (e) => { e.preventDefault(); openCart(); });
closeCart.addEventListener('click', closeCartFunc);
cartOverlay.addEventListener('click', closeCartFunc);

// Add to Cart Logic (Advanced Size Selector & Toast)
document.querySelectorAll('.add-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const productCard = this.closest('.product-card');
        const img = productCard.querySelector('.p-img-main').src;
        const name = this.getAttribute('data-name');
        const price = this.getAttribute('data-price');
        const size = this.getAttribute('data-size');
        
        const itemName = size ? `${name} - Size ${size}` : name;
        
        // Add to array
        cart.push({ name: itemName, price, img });
        
        // Show Micro-interaction Toast
        const toast = document.createElement('div');
        toast.className = 'toast-msg';
        toast.innerHTML = `✔ ADDED <strong>${itemName}</strong>`;
        document.getElementById('toast-container').appendChild(toast);
        
        // Visual feedback on button
        const originalText = this.innerHTML;
        this.innerHTML = '✔';
        this.style.background = '#111';
        this.style.color = 'white';
        this.style.borderColor = '#111';
        
        setTimeout(() => {
            this.innerHTML = originalText;
            this.style.background = '';
            this.style.color = '';
            this.style.borderColor = '';
            
            // Remove toast
            setTimeout(() => { if (toast.parentNode) toast.remove(); }, 2500);
            
            // Pop open the cart
            updateCartUI();
            openCart();
        }, 500);
    });
});

// Mock Secure Checkout
checkoutBtn.addEventListener('click', function() {
    if(this.disabled) return;
    this.innerHTML = '<svg class="spin lock-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg> Initializing Secure Gateway...';
    
    setTimeout(() => {
        this.innerHTML = 'Paystack Connected ✔';
        this.style.background = '#0ba4db'; // Paystack color
        
        // In real setting, redirect here. We just reset for mockup.
        setTimeout(() => {
            closeCartFunc();
            this.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="lock-icon"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg> Checkout Securely';
            this.style.background = '';
            
            // Clear cart post checkout mockup
            cart = [];
            updateCartUI();
        }, 3000);
    }, 1500);
});
