// Custom Cursor
const cursor = document.querySelector('.cursor-glow');
if (window.innerWidth > 900) {
    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX + 'px';
        cursor.style.top = e.clientY + 'px';
    });

    document.querySelectorAll('a, button, .day.available, .s-card, .logo, .cal-nav').forEach(el => {
        el.addEventListener('mouseenter', () => cursor.classList.add('hovering'));
        el.addEventListener('mouseleave', () => cursor.classList.remove('hovering'));
    });
}

// Parallax Hero
const heroBg = document.querySelector('.hero-bg');
window.addEventListener('scroll', () => {
    const scroll = window.pageYOffset;
    if (scroll < window.innerHeight) {
        // Subtle translate and scale
        heroBg.style.transform = `translateY(${scroll * 0.3}px) scale(${1 + scroll * 0.0002})`;
    }
});

// Cinematic Reveal Animations
const observerOptions = {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if(entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// Interactive Booking Calendar Mockup
const availableDays = document.querySelectorAll('.day.available');
const timeSlots = document.getElementById('time-slots');
const selectedDateSpan = document.getElementById('selected-date');
const tBtns = document.querySelectorAll('.t-btn');
const confirmBtn = document.querySelector('.complete-btn');

availableDays.forEach(day => {
    day.addEventListener('click', () => {
        // Reset states
        availableDays.forEach(d => {
            d.style.boxShadow = '';
            d.style.background = '';
            d.style.color = '';
        });
        
        // Active state
        day.style.boxShadow = '0 0 0 2px var(--bg), 0 0 0 4px var(--accent)';
        day.style.background = '#fff';
        day.style.color = 'var(--bg)';
        selectedDateSpan.textContent = `Mar ${day.textContent}`;
        timeSlots.style.display = 'block';
        
        // Smooth scroll to times
        setTimeout(() => {
            timeSlots.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 100);
    });
});

tBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        tBtns.forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        confirmBtn.textContent = `Confirm for ${btn.textContent}`;
    });
});

confirmBtn.addEventListener('click', () => {
    if(confirmBtn.textContent !== 'Confirm Reservation' && !confirmBtn.textContent.includes('Secured')) {
        const originalText = confirmBtn.textContent;
        confirmBtn.textContent = 'Processing...';
        confirmBtn.style.opacity = '0.7';
        
        setTimeout(() => {
            confirmBtn.style.opacity = '1';
            confirmBtn.style.background = '#E0A96D';
            confirmBtn.style.color = '#0B0A0A';
            confirmBtn.textContent = 'Reservation Secured ✓';
        }, 1200);
    }
});

// Fullscreen Menu Logic
const menuBtn = document.getElementById('menu-btn');
const closeBtn = document.getElementById('close-btn');
const fsMenu = document.getElementById('fs-menu');
const menuLinks = document.querySelectorAll('.menu-link');

if(menuBtn) {
    menuBtn.addEventListener('click', () => {
        fsMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });

    closeBtn.addEventListener('click', () => {
        fsMenu.classList.remove('active');
        document.body.style.overflow = 'auto';
    });

    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            fsMenu.classList.remove('active');
            document.body.style.overflow = 'auto';
        });
    });
    
    // Add custom cursor hover to new elements
    document.querySelectorAll('.menu-link, .close-btn, .menu-btn, .m-item').forEach(el => {
        el.addEventListener('mouseenter', () => document.querySelector('.cursor-glow').classList.add('hovering'));
        el.addEventListener('mouseleave', () => document.querySelector('.cursor-glow').classList.remove('hovering'));
    });
}

// Smooth scrolling for Anchor Links (Reserve Button FIX)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        if(targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if(targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        
        // Ensure menu closes if open
        if(fsMenu && fsMenu.classList.contains('active')) {
            fsMenu.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    });
});
